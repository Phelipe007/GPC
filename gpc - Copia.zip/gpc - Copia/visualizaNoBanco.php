<?php
function salvaNoBanco($tabela, $campos, $valores) {
    include "dbc.php";

    // Verificação para saber se esles estão alinhados
    if (count($campos) !== count($valores)) {
        die("<script> alert(Erro: O número de campos e valores não corresponde.) </script>");
    }

    // Construindo a query
    $sql = "SELECT " . implode(", " , $valores) . "FROM $tabela";

    try {
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute()) {
            return $r = true . $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            return [];
        }
    } catch (PDOException $e) {
        die("Erro: " . $e->getMessage());
    }
}
?>
