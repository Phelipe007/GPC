Sobre o GPC 🚴‍♀️

GPC (Gestão do Passeio Ciclístico) é um projeto desenvolvido por alunos do terceiro ano do curso técnico em Informática do IFMT. Nosso objetivo é criar um site para gerenciar o Passeio Ciclístico, um evento tradicional do campus, e futuramente expandi-lo para o gerenciamento de eventos gerais do IFMT.

A equipe é composta por Giovanna Beatriz, Henrique dos Anjos, Pheipe Oliveira, Thais Feliciana e João Heitor. Como estudantes, estamos aplicando nossos conhecimentos em desenvolvimento web para facilitar a organização e o acesso aos eventos do campus.

Atualmente, o GPC está focado no gerenciamento de inscrições, cronogramas e informações relevantes para os participantes do Passeio Ciclístico. No futuro, planejamos tornar o sistema mais abrangente, promovendo a inclusão de outros tipos de eventos do IFMT.

Este projeto é mais do que um trabalho acadêmico: é uma iniciativa para fortalecer a comunidade do nosso instituto.
